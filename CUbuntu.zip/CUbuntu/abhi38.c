#include<stdio.h>
int main()
{
main()
message();
{
message()
}
printf("oh yes abhi");
main();
return 0;
}
