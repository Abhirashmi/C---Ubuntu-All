#include<stdio.h>
#include<stdlib.h>
int main()
{
int a,b,c,n=0;
printf("enter your marks in maths %d",a);
printf("enter your marks in physics %d",b);
printf("enter your marks in chemistry %d",c);
int s=0;
s=a+b+c;
printf("your total marks %d",s);
int p=0;
p=(s/300)*100;
printf("your  percentage %d",p);
if(p>=90)
{
n=1;
}
else if(p>=80)
{
n=2;
}
else if(p>=80)
{
n=3;
}
else if(p>=70)
{
n=4;
}
else if(p>=60)
{
n=5;
}
else if(p>=50)
{
n=6;
}
else
{
n=7;
}
switch()
{
case 1:
printf("outstanding");
break;
case 2:
printf("excellent");
break;
case 3:
printf("Grade A");
break;
case 4:
printf("Grade B");
break;
case 5:
printf("Grade c");
break;
case 6:
printf("Grade D");
break;
case 7:
printf("STUDY HARD!!!");
break;
default:
printf("lol, you have'nt appeared for the exam");
}
return 0;
}

