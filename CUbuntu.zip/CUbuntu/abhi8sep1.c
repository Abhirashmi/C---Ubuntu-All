#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct student {
int id;
char name[20];
float percentage;
};
int main()
{
struct student record1;
record1.id=1123;
strcpy(record1.name,"abhirashmi");
record1.percentage=84.00;
printf("id %d   name = %s percentage = %f\n",record1.id,record1.name,record1.percentage);
printf("bye");
struct student record2;
record2.id=1124;
strcpy(record2.name,"arnav");
record2.percentage=94.90;
printf("id %d   name = %s percentage = %f\n",record2.id,record2.name,record2.percentage);
struct student record3;
record3.id=1144;
strcpy(record3.name,"anita kumari");
record3.percentage=55.00;
printf("id %d   name = %s percentage = %f\n",record3.id,record3.name,record3.percentage);
printf("bye");
return 0;
}
