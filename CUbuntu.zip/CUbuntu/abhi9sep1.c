#include<stdio.h>
#include<stdlib.h>
#define PI 3.14
int main()
{
printf("\t\tpi=%f\a",PI);
return 0;
}

