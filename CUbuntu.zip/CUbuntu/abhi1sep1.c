#include<stdio.h>
#include<stdlib.h>
int main()
{
int a,b,c,s=0;
int per=0;
printf("enter your marks in maths %d",a);
printf("enter your marks in physics %d",b);
printf("enter your marks in chemistry %d",c);
s=a+b+c;
printf("total marks obtained=%d",s);
per=(s/300)*100;
printf("your percentage is %d",per);
switch(per)
{
case (per>=90):
printf("outstanding");
break;
case (per>=80&& per<90):
printf("excellent");
break;
case (per>=70 && per<80):
printf("grade A ");
break;
case (per>=60&& per<70):
printf("grade B");
break;
case (per<60):
printf("grade C");
break;
default :
printf("lol you havent appeared for the exam");
}
return 0;
}


