#include<stdio.h>
int main()
{
char ch;
printf("input a character\n");
scanf("%c",&ch);
switch(ch)
{
case 'a':
case 'e':
case 'i':
case 'o':
case 'u':
case 'A':
case 'E':
case 'O':
case 'I':
case 'U':
printf("%c is a vowel.\n",ch);
break;
default:
printf("%c is not a vowel.\n",ch);
}
return 0;
}
