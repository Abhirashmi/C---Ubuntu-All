#include<stdio.h>
#include<stdlib.h>
int main()
{
int i=0;
while(i<20)
{
printf("ABHIRASHMI \n ");
i++;
}
return 0;
}
