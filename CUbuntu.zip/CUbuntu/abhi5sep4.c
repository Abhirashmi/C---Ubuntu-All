#include<stdio.h>
#include<stdlib.h>
int sum(int a, int b){
printf("enter the value of a and b %d ,%d",a,b);
scanf("%d %d ",&a,&b);
int sum=a+b;
printf("sum=%d",sum);
}
int main()
{
int sum(int a,int b);
return 0;
}



