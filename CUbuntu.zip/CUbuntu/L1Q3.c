#include<stdio.h>

int main()
{
    int num;
    char ch;

    printf("Enter an integer: ");
    scanf("%d", &num);

    for(int i=0; i<32; i+=8) {
        ch = num >> i;
        printf("%d\n", ch);
    }
    
    return 0;
}