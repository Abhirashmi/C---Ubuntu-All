#include<stdio.h>
#include<stdlib.h>
int main()
{
int val_arr[3]={2,6,9};
int *pointer_arr[3];
for(int i=0;i<3;i++)
{
pointer_arr[i]=&val_arr[i];
}
for(int i=0;i<3;i++)
{
printf(" the value of val_arr[%d]=%d\n",i,*pointer_arr[i]);//gives the value of array
printf(" the address of val_arr[%d]=%d\n",i,pointer_arr[i]);//gives the address of array
}
return 0;
}


