#include<stdio.h>
int main()
{
int len,i,j,rows;
printf("enter the number of rows\n");
scanf("%d",&rows);
for(i=0;i<rows;i++)
{
for(j=0;j<rows;j++)
{
if(i==j || i+j==rows-1)
{
printf("%d",i+1);
}
else
{
printf(" ");
}
}
printf("\n");
}
return 0;
}


