#include <stdio.h>

int main()

{

int i,j,n,flag=0,m,flag1=0,l,t;

printf("Enter the number\n");

scanf("%d",&n);

l=n;

t=n;

for(i=1;i<2*n;i++)

{

if(i==n+1||flag!=0)

{

flag=flag+2;

}

t=n;

flag1=0;

for(j=1;j<2*n;j++)

{

if(j==n+1||flag1!=0)

{

flag1=flag1+2;

}

m=(l+flag)>(t+flag1)?(l+flag):(t+flag1);

printf("%d\t",m);

t--;

}

printf("\n");

l--;

}

return 0;

}
