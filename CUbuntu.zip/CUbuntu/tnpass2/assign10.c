#include<stdio.h>
int main(){
int m ;
int k = 0;
int i,j, n ;
printf("enter the number");
scanf("%d",&m);
if(m%2==0){
for(i=1 ;i<=(m/2);i++)
{
for(j=1;j<=m;j++)
{
printf("%d",(m*k)+j);
if(j<m)
{
printf("*");
}
}
printf("\n");
k = k+2;
}
int p , s;
int l = m-1;
for(p =1;p<=((m)/2);p++)
{
for(s=1;s<=m;s++)
{
printf("%d",(m*l)+s);
if(s<m)
{
printf("*");
}
}
printf("\n");
l = l-2;
}
}
else
{
int g = m+1 ;
for(i=1 ;i<=(g/2);i++)
{
for(j=1;j<=m;j++)
{
printf("%d",(m*k)+j);
if(j<m)
{
printf("*");
}
}
printf("\n");
k = k+2;
}
int p , s;
int l = m-2;
for(p =1;p<((g)/2);p++)
{
for(s=1;s<=m;s++)
{
printf("%d",(m*l)+s);
if(s<m)
{
printf("*");
}
}
printf("\n");
l = l-2;
}
}
return 0;
}
