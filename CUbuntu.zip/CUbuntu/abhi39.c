void display()
{
printf("abhi");
}
