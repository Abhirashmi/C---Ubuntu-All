#include<stdio.h>
#include<stdlib.h>
#include<string.h>//header file for string
int main()
{
char string1[12]="hello";
char string2[12]="abhirashmi";
char string3[12];
strcpy(string3,string1);//string copying (to destination,from string)
strcat(string1,string2);//concatinate 2 strings (join string 2 to string1)
int str_length1 =strlen(string1);//gives the lenght of string
printf("string copy %s\n",string3);
printf("string concatination or adding  %s\n",string1);
printf("string length %d\n",str_length1);
printf(" BYE !! GOOD NIGHT\n");
return 0;
}

