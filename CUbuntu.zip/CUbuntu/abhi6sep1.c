#include<stdio.h>
#include<stdlib.h>
int main()
{
int myarr[3] [3]={
{1,8,9},//row0
{19,38,95},//row1
{13,68,49}//row2
};
for (int i=0;i<3;i++)
{
for (int j=0;i<3;j++)
{
printf("my arr [%d][%d]=%d \n",i,j,myarr[i][j]);
}

}
return 0;
}

