#include<stdio.h>
int main()
{
india();
africa();
goa();
}
india()
{
printf("i am in india\n");
}
africa()
{
printf("i am in africa\n");
}
goa()
{
printf("i am in goa\n");
}

