#include<stdio.h>
#include<stdlib.h>
#include<string.h>//header file for string

int main()
{
char my_string[6]={'a','b','c','d','e','f','g'};//definite size array
char my_other_string[]="hello abhirashmi";//undefinite size
printf("my string is %s \n",my_string);
printf("my string is %s \n",my_other_string);
}
