#include<stdio.h>
#include<stdlib.h>
int main()
{
int myarr[3]={5,75,8};
char mychar[9]={'a','e','i','o'};
mychar[2]='u';
int acs=myarr[2];
printf("value=%d ",acs);
int acs1=mychar[2];
for(int i=0;i<=3;i++)
printf("value %d =%c \n ",i,mychar[i]);
return 0;
}

