#include<stdio.h>
#include<stdlib.h>
int main()
{
int n,sum=0;
int v;
printf("how many numbers you want to add?\n",n);
scanf("%d",&n);
printf("enter  %d numbers \n",n);
for(int i=0;i<n;i++)
{
scanf("%d",&v);
sum=sum+v;
}
printf("sum of %d numbers are:%d",n,sum);
return 0;
}
