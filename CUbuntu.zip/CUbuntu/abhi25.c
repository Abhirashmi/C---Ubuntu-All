#include<stdio.h>
int main()
{
int a,b,c;
printf("enter two numbers to subtract\n");
scanf("%d%d",&a,&b);
c=a-b;
printf("the answer is %d\n",c);
return 0;
}
