#include<stdio.h>
int main()
{
char a='\012';
printf("%d",a);
return 0;
}
