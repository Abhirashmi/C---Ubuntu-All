#include<stdio.h>
int main()
{
///typedef<previous_name> <alias_name>;
ul l1,l2,l3=0;
typedef int u1;
printf("l1 =%d \n",l1);





return 0;
}
