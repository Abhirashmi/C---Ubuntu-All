#include<stdio.h>
int main()
{
int a[50],i,n,sum;
printf("enter the size of the array");
scanf("%d",&n);
printf("enter the elements of the array");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
sum=sum+a[i];
printf("%d",sum);
}
printf("the sum equals to %d",sum);
return 0;
}

