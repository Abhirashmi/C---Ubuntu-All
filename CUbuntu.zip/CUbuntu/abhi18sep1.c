#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int generate_random_num(int n)
{
srand(time(NULL));
return rand() % n;
};
int greator(char c1,char c2)
{


int main()
{
int playerscore=0,temp;
int computerscore=0;
char playerchar,compchar;
printf("\nhey players welcome to rock paper scissor game created by abhirashmi\n");
for(int i=0;i<3;i++)
{

printf("players 1 turn\n");
printf("\nchoose 1 for rock 2 for paper 3 for scissors\n");
}
printf("\nchoose 1 for rock 2 for paper 3 for scissors\n",player2);
printf("\nthe random number generated between 0 to 5  is %d\n ",generate_random_num(2));
srand(time(NULL));
return 0;
}

