#include<stdio.h>
int main()
{
int s1,s2,s3,s4,s5,per;
printf("enter the marks of five subject");
scanf("%d""%d""%d""%d""%d",&s1,&s2,&s3,&s4,&s5);
per=(s1+s2+s3+s4+s5)/5;
if((per<=100)&&(per>30))
printf("excellent work");
else
{
if(per<=30)
printf("such a noob XD");
}
return 0;
}
