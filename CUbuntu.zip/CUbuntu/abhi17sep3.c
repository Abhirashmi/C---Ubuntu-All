#include<stdio.h>///use of malloc
#include<stdlib.h>
int main()
{
int*ptr;
int n;
ptr =(int *)malloc(10*sizeof(int));   
for(int i=0;i<5;i++)
{
printf("enter the value  no at  %d of the array\n",i);
scanf("%d",&ptr[i]);
}

for(int i=0;i<5;i++)
{
printf(" \nthe value you have entered at %d is %d of the array\n",i,ptr[i]);
}

printf("\nenter the size of new array you want to create %d \n",n);
scanf("%d",&n);
ptr =(int *)realloc( ptr,n*sizeof(int));
   
for(int i=0;i<n;i++)
{
printf("\nenter the value no at  %d of the new array you want to \n",i);
scanf("%d",&ptr[i]);
}
printf(" \n   NEW ARRAY    \n");
for(int i=0;i<n;i++)
{
printf("\n the value you have entered at %d is %d \n",i,ptr[i]);
}
return 0;
}

