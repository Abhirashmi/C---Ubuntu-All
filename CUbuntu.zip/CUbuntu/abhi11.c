#include<stdio.h>
int main()
{
printf("OH YES ABHI");
return 0;
}
