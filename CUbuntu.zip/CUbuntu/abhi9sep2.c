#include<stdio.h>
#include<stdlib.h>
int main()
{
int s,m;
printf("enter your marks of science %d\n",s);
scanf("%d",&s); 
printf("enter your marks of maths %d\n",m);
scanf("%d",&m);
printf("you have got %d  marks in science and  %d marks in maths out of 100\n",s,m);
if(s>52 && m>52)
{
printf("congratulation !!! you will be given 45 rupees\n");
}
else if (s>52)
{
printf("congratulation !!! you will be given 15 rupees\n");
}
else if (m>52)
{
printf("congratulation !!! you will be given 15 rupees\n");
}
else 
{
printf("better luck next time\n");
}
return 0;
}
