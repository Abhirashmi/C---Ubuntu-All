#include<stdio.h>
#include<stdlib.h>
int main()
{
int a=19,b=20;
int c;
c=(a>b)?b:a;
printf("ans=%d",c);
return 0;
}
