#include<stdio.h>
float euler function(float t1,float t2);
int main
{
float start value,end value,t1,t2,width,temp,z;
printf("\n ENTER VALUE FOR INTERVAL START:\t");
scanf("%f",&start value);
printf("\n ENTER VALUE FOR INTERVAL END:\t");
scanf("%f",&end value);
printf("\n ENTER VALUE FOR WIDTH:\t");
scanf("%f",&width);
printf("\n ENTER VALUE FOR ERROR:\t");
scanf("%f",&temp);
t1=start value;
t2=end value;
printf("\nX\tcorresponding y values\n");
while(t1 <= temp)
{
z=width*euler function(t1,t2);
t2=t2+z;
t1=t2+width;
printf("%0.4f\t%0.4f\n",t1,t2);
}
return 0;
}
float euler function(float t1,float t2)
{
float temp;
temp= t1+t2;return temp;
}

