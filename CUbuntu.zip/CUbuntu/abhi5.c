#include<stdio.h>
int main()
{
int x,y,sum;
printf("ENTER THE VALUES OF X AND Y:\n");
scanf("%d%d",&x,&y);
sum=x+y;
printf("the sum is %d",sum);
return 0;
}
