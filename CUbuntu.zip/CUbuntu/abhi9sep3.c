#include<stdio.h>
#include<stdlib.h>
int main()
{
int s,e,h,m,soc_sci;
printf("marks obtained in science out of 100 ? %d \n",s);
scanf("%d",&s);
printf("marks obtained in english out of 100 ? %d\n",e);
scanf("%d",&e);
printf("marks obtained in hindi out of 100 ? %d\n",h);
scanf("%d",&h);
printf("marks obtained in maths out of 100 ?%d\n",m);
scanf("%d",&s);
printf("marks obtained in social science out of 100 ?%d\n",soc_sci);
scanf("%d",&s);
printf(" you have obtained in %d,%d,%d,%d,%d in science,english ,hindi,mathematics and social science respectively . \n",s,e,h,m,soc_sci);
int t,p=0;
t=(s+e+h+m+soc_sci);
p=(t/500)*100;
printf(" your total marks out of 500 is %d \n",t);
printf(" your perentage %d \n",p);
int n;
if(p>90)
{
n=1;
}
else if(p>80)
{
n=2;
}
else if(p>70)
{
n=3;
}
else if(p>60)
{
n=4;
}
else
{
n=5;
}
switch(n)
{
case(1):
printf("OUTSTANDING \n");
break;
case(2):
printf("EXCELLENT \n");
break;
case(3):
printf("Grade A \n");
break;
case(4):
printf("Grade B \n");
break;
case(5):
printf("Grade C \n");
break;
default:
printf("study hard!!!!!\n");
break;
}
printf("bye!!! good night!!\n");
return 0;
}


