#include<stdio.h>///use of malloc
#include<stdlib.h>
int main()
{
int*ptr;
ptr =(int *)malloc(10*sizeof(int));   
for(int i=0;i<5;i++)
{
printf("enter the value  no at  %d of the array\n",i);
scanf("%d",&ptr[i]);
}
for(int i=0;i<5;i++)
{
printf(" the value you have entered at %d is %d of the array\n",i,ptr[i]);
}
return 0;
}

