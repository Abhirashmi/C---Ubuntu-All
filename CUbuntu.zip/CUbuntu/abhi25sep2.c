#include<stdio.h>
int main()
{
int a,i=0;
int *i2;
while(i<455556)
{
printf(" hey abhirashmi for %d th time \n ",i);
i2=malloc(567888*sizeof(int));
if(i%100==0)
{
getchar();
}
i++;
}
return 0;
}
