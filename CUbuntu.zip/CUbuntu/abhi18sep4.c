#include<stdio.h>
int main()
{
int m,n;
int sum=0;
int a[3][4],b[4][2];
int result[3][2];
printf("\n*******************MATRIX MULTIPLICATION******************\n");
printf("\n  Enter your first matrix \n");
for(int i=0;i<3;i++)
{
for(int j=0;j<4;j++)
{
printf("enter the [%d][%d] element of your first matrix \n",i,j);
scanf("%d",&a);
}
}
printf("\n  Enter your second  matrix \n");
for(int i=0;i<4;i++)
{
for(int j=0;j<2;j++)
{
printf("enter the [%d][%d] element of your second  matrix \n",i,j);
scanf("%d",&b);
}
}

printf("\n   your resultant matrix  matrix \n");
for(int i=0;i<3;i++)
{
for(int j=0;j<2;j++)
{
for(int k=0; k<4;k++)
{
sum=sum+a[i][k]*b[k][j];
result[i][j]=sum;
sum=0;
}
}
}
for( int i=0;i<3;i++)
{
for(int j=0;j<2;j++)
{
printf("the [%d][%d] element of your resultant matrix  is {%d}  \n",i,j,result[i][j]);
}
}
printf("bye\n");
return 0;
}
