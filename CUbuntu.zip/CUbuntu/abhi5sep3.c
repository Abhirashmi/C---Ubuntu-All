#include<stdio.h>
#include<stdlib.h>
int main()
{
int n,f,i;
printf("enter the number whose factorial you want to find",n);
scanf("%d",&n);
if(n<0)
{
printf("factorial of negative number does'nt exist.");
}
else if(n=0)
{
printf("factorial of 0 is 1");
}
else(n>0)
{
for(int i=1;i<=n;i++)
{
f=f*i;
}
printf("factorial of %d=%d",n,f);
}
return 0;
}
