#include<stdio.h>
#include<stdlib.h>
int main()
{
int n;
printf("how many lines of * pattern rows  want to draw ?\n",n);
scanf("%d",&n);
for (int i=0;i<n;i++)
{
for(int j=0;j<i;j++)
{
printf(" * ");
}
printf("\n");
}
printf("bye \n");
return 0;
}
