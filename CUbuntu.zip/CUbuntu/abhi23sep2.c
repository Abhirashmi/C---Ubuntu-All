#include<stdio.h>
int main()
{
FILE *ptr =NULL;
ptr = fopen("my_file.txt","r+");

return 0;
}
