#include<stdio.h>
#include<stdlib.h>
int factorial(int num)
{
if(num==1 ||num==0)
{
return 1;
}
else 
{
return( num * factorial(num-1));
}
}
int main()
{
int n;
printf("enter the number whose factorial you want to get %d",n);
scanf("%d",&n);
printf("the number you have entered is %d and its factorial is %d",n,factorial(n));
printf("bye !!!!");
return 0;
}


