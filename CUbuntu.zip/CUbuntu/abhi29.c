#include<stdio.h>
int main()
{
system("c:\\windowns\\system32\\ipconfig");
return 0;
}
