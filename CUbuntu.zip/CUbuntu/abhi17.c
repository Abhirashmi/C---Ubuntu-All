#include<stdio.h>
int main()
{
int a[10],i,n;
printf("enter the size of the array");
scanf("%d",&n);
printf("enter the elements of the array");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
printf("display");
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}
return 0;
}

