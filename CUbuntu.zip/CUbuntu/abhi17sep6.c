#include<stdio.h>
int myfunc()
{
int a=99;
return a;
};
int main()
{
int *ptr= myfunc();
printf(" value of ptr %d \n ",*ptr);
return 0;
}
