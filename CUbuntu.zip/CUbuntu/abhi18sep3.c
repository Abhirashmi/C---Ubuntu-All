#include<stdio.h>
int main()
{
printf("this file name is %s \n",__FILE__);
printf("today's date %s\n",__DATE__);
printf("CURRENT TIME  is %s\n",__TIME__);
printf(" THIS file %s line no is %d\n",__FILE__,__LINE__);
printf("ANSI :%d\n",__STDC__);
printf("BYE\n");
return 0;
}
