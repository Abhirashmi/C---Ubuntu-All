#include<stdio.h>
int main()
{
int a[50],i,n,lar;
printf("enter the size of the array");
scanf("%d",&n);
printf("enter the elements of the array");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
lar=a[0];
for(i=1;i<n;i++)
{
 if(a[i]>lar)
 {
lar=a[i];
}
}
printf("the large equals to %d",lar);
return 0;
}

