#include<stdio.h>
int main()
{
int x=1,sum=0;
while(x<=999)
{
sum=sum+x;
x=x+1;
}
printf("THE SUM OF 999 NATURAL NUMBERS IS:%d",sum);
return 0;
}
