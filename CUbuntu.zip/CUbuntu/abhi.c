#include<Stdio.h>
int main()
{
printf("abhirashmi kumari");

return 0;
}
