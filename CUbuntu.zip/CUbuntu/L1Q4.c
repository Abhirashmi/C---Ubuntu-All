#include<stdio.h>

struct pkt
{
    char ch1;
    char ch2[2];
    char ch3;
};

int main()
{
    struct pkt p1;
    int num;

    printf("Enter an integer: ");
    scanf("%d", &num);

    p1.ch1 = num >> 0;
    p1.ch2[0] = num >> 8;
    p1.ch2[1] = num >> 16;
    p1.ch3 = num >> 24;

    int result = (p1.ch1 | p1.ch2[0] | p1.ch2[1] | p1.ch3);

    printf("Aggregated result is: %d\n", result);

    return 0;
}
