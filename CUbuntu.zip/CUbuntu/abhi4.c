#include<stdio.h>
int main()
{
printf("ABHIRASHMI KUMARI\nCSSE\nKIIT UNIVERSITY\n");
return 0;
}
