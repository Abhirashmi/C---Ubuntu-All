#include<stdio.h>
#include<stdlib.h>
int main()
{
int v;
int *pointer_p;
pointer_p=&v;
printf("enter the value of v %d \n",v);
scanf("%d",&v);
printf("the address of %d is %x \n ",v,&v);
printf("the value of pointer_p is %x \n ",pointer_p);
printf("the value of pointer %d \n ",*pointer_p);

printf("bye");
return 0;
}
