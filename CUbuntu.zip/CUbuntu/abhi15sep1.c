#include<stdio.h>
struct student 
{
int id;
int marks;
char fav_char;
char name[36];
};
int main()
{
struct student s1;
s1.id=222;
s1.marks=55;
s1.fav_char="a";
s1.name="abhirashmi";
return 0;
}
