#include<stdio.h>
int main()
{
int i=2;
display(i);
}
