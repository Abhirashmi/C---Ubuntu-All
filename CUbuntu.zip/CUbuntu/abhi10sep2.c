#include<stdio.h>
#include<stdlib.h>
int main()
{
int a=9;
float b=54.66;
float c=54.66/a;//typecasting syntax
printf("value of b = %f\n",b);
printf("value of b = %i\n",(int)b);
printf("value of b = %f\n",b);
printf("value of c  = %f\n",c);
printf("value of c = %i\n",(int)c);
return 0;
}


