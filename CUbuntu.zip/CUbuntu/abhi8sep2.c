#include<stdio.h>
#include<stdlib.h>
#include<string.h>
union myunion{
int myint//4
char mychar//1
};
int main()
{
union myunion uni;
uni.myint=1;
uni.mychar=4;
printf("my integer %i \n",uni.myint);
printf("my char %c \n",uni.mychar);
printf("bye ");
}
