#include<stdio.h>
int main()
{
int num;
printf("enter a number");
scanf("%d",&num);
if(num <=100)
printf("oh yeah");
return 0;
}
