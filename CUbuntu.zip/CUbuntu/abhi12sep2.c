#include<stdio.h>
#include<stdlib.h>
int main()
{
int mark[6];
for(int i=1;i<10;i++)
{
printf("enter your marks %d \n",mark[i]);
scanf("%d",&mark[i]);
}
for(int i=1;i<10;i++)
{
printf("  marks of roll no. %d  = %d\n ",i,mark[i]);
}
printf("bye");
return 0;
}
