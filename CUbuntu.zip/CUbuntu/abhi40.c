#include<stdio.h>
int main()
{
int i;
printf("enter a number");
scanf("%d",&i);
while(i>0)
printf("oh yeah");
return 0;
}
