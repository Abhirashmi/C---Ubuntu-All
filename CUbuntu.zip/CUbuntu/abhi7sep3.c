#include<stdio.h>
#include<stdlib.h>
int getsum(int *arr_val,int size)
{
int sum=0;
for(int i=0;i<size;i++)
{
sum=sum+arr_val[i];
}
return sum;
}
int main()
{
int my_arr[4]={2,5,8,9};
int mysum=getsum(my_arr,4);
printf("sum of array =%d\n",mysum);

return 0;
}

