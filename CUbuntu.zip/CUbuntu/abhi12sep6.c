#include<stdio.h>
#include<stdlib.h>
int main()
{
int i,n,t1=0,t2=1,next_term;
printf("enter the number of terms: %d\n",n);
scanf("%d",&n);
printf("fibonacci series : ");
for(i=0;i<n;i++)
{
printf("  %d ,",t1);
next_term=t1+t2;
t1=t2;
t2=next_term;
}
printf("bye\n");
return 0;
}
