#include<stdio.h>
int main()
{
int a=99;
int *ptr=NULL;
if(ptr != NULL)
{
printf("the address of a is %d \n",ptr);
}
else
{
printf(" * ptr is a null pointer and cannot be dereferenced \n");
}
return 0;
}
