#include<stdio.h>
#include<stdlib.h>

int mul(int a,int b)
{
return(a*b);
}
int main()
{
int x,y;
printf("enter two numbers \n");
printf("number1 %d \n",x);
scanf("%d",&x);
printf("number2 %d \n",y);
scanf("%d",&y);
int prod;
prod=mul(x*y);
printf("product =%d",prod);
}

