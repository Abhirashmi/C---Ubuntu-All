#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct employee
{
int id;
int sal;
char fav_char;
};
int main()
{
struct employee e1;
{
e1.id=1234;
e1.sal=35000;
e1.fav_char=("A");
printf(" employee id = %d \n ,employee sal =%d \n, employee favourite character = %c\n ",e1.id,e1.sal,e1.fav_char,);
}
printf("bye\n");
return 0;
}

