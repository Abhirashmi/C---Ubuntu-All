#include<stdio.h>
#define PI 3.14
#define SQUARE(x) x*x
int main()
{
float  var=PI;
int r=6;

printf("\nthe value of PI is %f\n",var);
printf("the area of circle having radius %d  is %f \n ",r,PI * SQUARE(r));
printf("BYE\n");
return 0;
}

