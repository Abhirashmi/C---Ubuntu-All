#include<stdio.h>
int myfunc(int a,int b)
{
static int myvar;
myvar++;
printf(" \n the value of my var is %d \n",myvar);
return myvar;
};
int main()
{
 int myvar=myfunc(5,6);
register myvar=myfunc(5,6);//cpu register help in accesing the variables faster
myvar=myfunc(5,6);
myvar=myfunc(5,6);
myvar=myfunc(5,6);
myvar=myfunc(5,6);
myvar=myfunc(5,6);
myvar=myfunc(5,6);
myvar=myfunc(5,6);
printf("\n done !\n ");
return 0;
}
