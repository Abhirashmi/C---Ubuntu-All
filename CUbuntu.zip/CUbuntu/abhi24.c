#include<stdio.h>
int main()
{
int a,b,c;
printf("enter two numbers to add\n");
scanf("%d%d",&a,&b);
c=a+b;
printf("the sum of the entered numbers are =%d\n",c);
return 0;
}
