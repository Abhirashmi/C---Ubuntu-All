#include<stdio.h>
#include<stdlib.h>
int fun1()
{
printf("sum: %d ",22+44);
}
int main()
{
  fun1();
return 0;
}

