#include<stdio.h>
#include<stdlib.h>
int y=8;////global variable

int main()
{
int y=90;///local variable
//printf("global var %d ",y);//global
printf("local var %d ",y);//local
return 0;
}

