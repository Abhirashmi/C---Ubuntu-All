#include<stdio.h>
int main()
{
int num,i;
printf("enter a number ");
scanf("%d"&num);
i=2;
while(i<=num-1)
{

