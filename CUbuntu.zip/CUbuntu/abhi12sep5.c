#include<stdio.h>
#include<stdlib.h>////&a=ptr
int main()
{
int a=2;
int *ptr=&a;
ptr++;
printf("%d \n",a);
printf("%d \n",&a);
printf("%d \n",ptr);
printf("%d\n ",ptr+1);
printf("%d ",ptr++);
return 0;
}
