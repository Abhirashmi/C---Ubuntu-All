#include<stdio.h>
#include<stdlib.h>
int sum(int a ,int b)
{
return a+b;
}
void fun1(int(*fptr)(int a,int b))
{
printf("hello peoples\n");
printf("the sum of 5 and 9 is %d \n",fptr(5,9));

}
void fun2(int(*fptr)(int a,int b))
{
printf("good morning peoples \n");
printf("the sum of 5 and 9 is %d \n",fptr(5,9));
}
int main()
{
int (*ptr)(int,int);
ptr = sum;
fun1(ptr);
fun2(ptr);
return 0;
}
