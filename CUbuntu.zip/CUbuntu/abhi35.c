#include<stdio.h>
int main()
{
printf("hey girl");
}
