#include<stdio.h>
#include<stdlib.h>
int mysumarr(int sumarr[],int size)
{
int sum=0;
for(int i;i < size;i++)
{
sum=sum+sumarr[i];
}
return sum;
}
int main()
{
int arrnum[6]={19,33,55,76,87,89};
int sum_of_arr=mysumarr(arrnum,6);

printf("sum of array= %d",sum_of_arr);

}
