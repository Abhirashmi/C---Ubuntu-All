#include<stdio.h>
#include<stdlib.h>
int main()
{
int a=998;
int *ptr;//wild pointer
//*ptr=789;
ptr=&a;//ptr is no longer a wild pointer
printf("the value of a is %d \n",*ptr);
return 0;
}
