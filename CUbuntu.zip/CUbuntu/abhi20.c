#include<stdio.h>
int main()
{
int a[50],i,n,small;
printf("enter the size of the array");
scanf("%d",&n);
printf("enter the elements of the array");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
small=a[0];
for(i=1;i<n;i++)
{
 if(a[i]<small)
 {
small=a[i];
}
}
printf("the small equals to %d",small);
return 0;
}

