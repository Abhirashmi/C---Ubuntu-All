#include<stdio.h>
int main()
{
printf("WELCOME TO C PROGRAMMING");
return 0;
}
