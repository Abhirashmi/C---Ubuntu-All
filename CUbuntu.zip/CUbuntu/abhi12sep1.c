#include<stdio.h>
#include<stdlib.h>
int main()
{
int mark[20];
mark[0]=88;
mark[1]=48;
mark[2]=89;
mark[3]=44;
mark[4]=90;
mark[5]=66;
mark[5]=77;
printf(" your marks = \n rollno1 %d\n rollno 2 %d\n rollno 3 %d\n rollno 4%d\n rollno 5 \n",mark[0],mark[1],mark[2],mark[3],mark[4],mark[5]);
printf("bye\n");
return 0;
}
