#include<stdio.h>
#include<stdlib.h>
int main()
{
int chars;int i=0;
char *ptr;
while(i<3)
printf("enter the number of characters in your employee id \n");
scanf("%d",&chars);
ptr=(char *)malloc(chars+1(char));
printf("enter your employee id \n");
scanf("%s",ptr);
printf("your employee id =%s",ptr);
free(ptr);
i++;
return 0;
}
