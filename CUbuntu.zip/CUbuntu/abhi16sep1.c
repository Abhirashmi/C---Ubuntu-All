#include<stdio.h>
#include<string.h>
struct driver_info
{
int id;
int age;
int km;
int driving_exp;
printf("enter your id =%d \n",id );
scanf("%d",&id);
printf("enter your age =%d \n",age );
scanf("%d",&age);
printf("enter kilometres you have travelled  =%d \n",km );
scanf("%d",&km);
printf("enter your driving experience  =%c \n",driving_exp );
scanf("%d",&driving_exp);
};
int main()
{
int n;
printf("********ABHI'S TRAVEL AGENCY***************\n");
printf("enter the number of drivers you have = %d \n",n);
scanf("%d",&n);
printf(" enter your detailes one by one\n");
for(int i=0;i<n;i++)
{
struct driver_info s[i];
}
return 0;
}

