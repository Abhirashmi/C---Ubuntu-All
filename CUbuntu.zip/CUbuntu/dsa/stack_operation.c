#include<stdio.h>
#include<stdlib.h>
struct stack
{
int size;
int top;
int *arr;
};


int isempty(struct stack *ptr)
{
if(ptr->top==-1)
{
printf("stack is empty : stack underflow\n");
}
else
{
printf("stack is not empty \n");
}
};


int isfull(struct stack *ptr)
{
if(ptr->top==ptr->size-1)
{
printf("stack is full : stack overflow \n");
}
else
{
printf("stack is not full \n");
}
};


int main()
{
struct stack *sp = (struct stack *)malloc(sizeof(struct stack));
{
sp->size=100;
sp->top=-1;
sp->arr=(int *)malloc(sp->size * sizeof(int));
}
printf("your stack has been created succesfully \n ");
isfull(sp);
isempty(sp);
return 0;
}
