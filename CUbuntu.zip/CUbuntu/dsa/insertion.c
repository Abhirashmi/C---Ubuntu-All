#include<stdio.h>
void display(int arr[],int n)
{
for(int i=0;i<n;i++)
{
printf("%d ",arr[i]);
}
}
void insertion(int arr,int capacity,int size,int element,int index);
{
if(size>=capacity)
{
printf("we cant insert as array is full kindly create different array\n ");
}
else 
{
printf("enter the element you want to insert \n");
scanf("%d",&element);
printf("enter at which index  you want to insert  the above element \n");
scanf("%d",&index);
for(int ;i




int main()
{
int arr[100]={2,66,89,8,67};
int size=5,int element=78;
display(arr,5);
int intertion(arr,capacity,size,element,index);
return 0;
}
