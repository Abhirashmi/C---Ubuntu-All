#include<stdio.h>
struct node{
int data;
struct node * next;
};
void link_list_traversal(struct node*ptr)
{
while(ptr != NULL)
{
printf("\n element : %d\n ",ptr->data);
ptr=ptr->next;
}
}
int main()
{
struct node *head;
struct node *second;
struct node *third;
head=(struct node*)malloc(sizeof(struct node));
second=(struct node*)malloc(sizeof(struct node));
third=(struct node*)malloc(sizeof(struct node));
head->data=7;
head->next=second;

second->data=79;
second->next=third;

third->data=756;
third->next=NULL;

link_list_traversal(head);


return 0;
}
