#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
};

void isempty(struct node * top)
{
if(top==NULL)
{
printf("stack is empty \n ");
}
else
{
printf("stack is not empty\n);
}
}

int isfull(struct node * top)
{
struct node *p=(struct node*p)malloc(sizeof(struct node));
if(p==NULL)
{
printf("stack is full\n ");
}
else
{
printf("stack is not full\n");
}

struct node *push(struct node*top,int x)
{
if(isfull(top))
{
printf("stack overflow\n");
}
else
{
struct node *n=(struct node*)malloc(sizeof(struct node));
n->data=x;
n->next=top;
top=n;
return top;
}
}
int main()
{
struct node *top=NULL;
top=push(top,75);




return 0;
}




