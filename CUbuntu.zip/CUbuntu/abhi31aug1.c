#include<stdio.h>
#include<stdlib.h>
int main()
{
int a=5,b=6;
int sum,mul,div,mod,sub;
sum=a+b;
mul=a*b;
div=a/b;
mod=a%b;
sub=a-b;
printf("sum=%d",sum);
printf("mul=%d",mul);
printf("div=%d",div);
printf("mod=%d",mod);
printf("sub=%d",sub);
return 0;
}
