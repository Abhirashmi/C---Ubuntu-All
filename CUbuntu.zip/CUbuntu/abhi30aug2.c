#include<stdio.h>
#include<stdlib.h>
int main()
{
int age;
char name[30]
age=20;
name="abhirashmi kumari";

printf("my name is %c and my age is %d",name,age);

return 0;
}
