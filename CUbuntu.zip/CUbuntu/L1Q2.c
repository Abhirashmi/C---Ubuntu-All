#include<stdio.h>

struct info {
    int roll_no; 
    char name[50];
    float CGPA; 
};

void printInfo(struct info *I){
    printf("Roll No: %d\n", I->roll_no);
    printf("Name: %s\n", I->name);
    printf("CGPA: %f\n", I->CGPA);
}

int main()
{
    struct info I1;

    printf("Enter Roll No: ");
    scanf("%d", &I1.roll_no);
    
    printf("Enter Name: ");
    scanf("%s", I1.name);

    printf("Enter CGPA: ");
    scanf("%f", &I1.CGPA);

    printInfo(&I1);

    return 0;
}