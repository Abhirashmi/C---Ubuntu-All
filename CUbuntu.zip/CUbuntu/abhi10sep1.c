#include<stdio.h>
#include<stdlib.h>
int main()
{
int i,j=0;
for(i=0,j;i<=9,j<=9;i++)
{
printf(" %d %d\n\a",j,i);
}
return 0;
}
