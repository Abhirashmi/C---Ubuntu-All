#include<stdio.h>
#include<stdlib.h>
int swap(int *x,int *y)
{
int temp;
temp = *x;
*x=*y;
*y=temp;
return 0;
}
int main()
{
int a,b;
a;
b;
printf("enter the number you want to swap by call by reference method %d and %d \n ",a,b);
scanf("%d ,%d \n",&a ,&b);
printf("before swapping %d and %d \n ",a,b);
swap(&a,&b);
printf("after  swapping %d and %d \n ",a,b);
printf("bye\n");
return 0;
}


