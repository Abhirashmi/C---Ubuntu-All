#include<stdio.h>
int temp;
void array_rev(int arr[])///array traversal//
{
for(int i=0;i<7/2;i++)
{
temp=arr[i];
arr[i]=arr[6-i];
arr[6-i]=temp;
}
};
int main()
{
int arr[]={1,2,3,4,5,6,7};
printf("\n before reversing the array\n");
for(int i=0;i<7;i++)
{
printf("the value at index %d of the given array is is %d \n",i,arr[i]);
}
array_rev(arr);
printf("\n after reversing the array\n");
for(int i=0;i<7;i++)
{
printf("the value at index %d of the given array is is %d \n",i,arr[i]);
}
return 0;
}
