#include<stdio.h>
int main()
{
char str*="hi abhirashmi";
int a;
int *ptr= (int *)malloc(sizeof(int));
free(ptr);
ptr=NULL;//no onger dangling
