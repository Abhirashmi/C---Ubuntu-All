#include <stdio.h>
#include<stdlib.h>
int main()
{
printf("hello ABHIRASHMI");
return 0;
}
