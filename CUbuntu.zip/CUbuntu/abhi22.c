#include<stdio.h> 
int main()
{
int x;
printf("input an integer lol insaaan \n");
scanf("%d",&x);
printf("the integer given by lol insaan was%d\n",x);
return 0;
}
