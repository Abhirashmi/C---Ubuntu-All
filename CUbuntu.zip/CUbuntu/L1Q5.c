#include<stdio.h>

int main()
{
    int num, bt[4], ad[4], s = 0, e = 3;
    char ch;

    printf("Enter a number: ");
    scanf("%d", &num);

    for(int i=0, j=0; i<32, j<4; i+=8, j++) {
        ch = num >> i;
        printf("%d\n", ch);

        bt[j] = ch;
    }

    char *pt = &num;

    for(int i=0, j=0; i<32, j<4; i+=8, pt++, j++) {
        printf("%d\n", *(pt));
        ad[j] = *(pt);
    }

    if(bt[0] == ad[0])
        printf("Little Endian\n");
    else
        printf("Big Endian\n");

    while(s < e) {
        int temp = bt[s];
        bt[s] = bt[e];
        bt[e] = temp;
        s++; e--;
    }

    printf("After changing the endianness: ");
    for(int i=0; i<4; ++i)
        printf("%d", bt[i]);
    printf("\n");
    
    return 0;
}