#include<stdio.h>
int main()
{
int *ptr;
{
int i=0;
ptr=&i;
}
printf("\n %d \n",*ptr);
return 0;
}
