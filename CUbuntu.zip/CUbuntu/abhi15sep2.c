#include<stdio.h>
#include<string.h>
struct student ////structure
{
int id;
int marks;
char fav_char;
char name[36];
};
int main()
{
struct student s1;
s1.id=222;
s1.marks=55;
s1.fav_char="a";
strcpy(s1.name,"abhirashmi");
printf(" the student id is is %d \n",s1.id);
printf(" the student marks is %d \n",s1.marks);
printf(" the  student favourite character is %d \n",s1.fav_char);
printf(" the student name is is %d \n",s1.name);
printf(" bye %d \n");
return 0;
}
