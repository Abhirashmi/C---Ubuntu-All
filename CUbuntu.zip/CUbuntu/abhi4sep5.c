#include<stdio.h>
#include<stdlib.h>
int main()
{
int a;
printf("enter the number whose table you want to get : %d ",a);
scanf("%d",&a);
for(int i=1;i<=10;i++)
{
int c=0;
c=a*i;
printf(" %d  *  %d = %d  \n ",a,i,c);
}
printf("bye");
return 0;
}

