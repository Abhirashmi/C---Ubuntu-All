#include<stdio.h>
int main()
{
int a=56;
float b=99.8;
void *ptr;
void *ptr1;
ptr=&a;
ptr1=&b;

printf(" the value of a is %d \n ",*((int*)ptr ));
printf(" the value of b  is %f \n ",*((float*)ptr1 ));
printf(" the value of b is %d \n ",*((int*)ptr1 ));
return 0;
return 0;
}
