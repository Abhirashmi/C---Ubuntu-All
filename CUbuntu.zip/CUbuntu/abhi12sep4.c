#include<stdio.h>
#include<stdlib.h>
int main()
{
int a,*ptr;
int*ptr2=NULL;
*ptr=&a;
printf("enter the value of a = %d \n",a);
scanf("%d",&a);
printf("the value   of a is = %d\n",&a );
printf("the addres of *ptr is = %d\n",&*ptr );
printf("the addres of *ptr1 is = %d\n",&*ptr2 );
printf("bye");
return 0;
}
