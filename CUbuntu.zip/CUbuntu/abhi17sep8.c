#include<stdio.h>
int functiondangling()
{
int a=88;
int b=99;
int sum=a+b;
return &sum;
};
int main()
{
int *ptr=(int*)malloc(7 *sizeof(int));
ptr[1]=989;
ptr[2]=945;
ptr[3]=45;
ptr[4]=77;
ptr[5]=997;
ptr[6]=979;
ptr[7]=96;
free(ptr);//dangling pointer 
 
int *dangptr=functiondangling();//ptr is now a dangling ptr

int *danglingptr3;
{

int a=55;
danglingptr3=&a;
}
//variable a goes out of scope








return 0;
}
