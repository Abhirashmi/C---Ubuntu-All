#include<stdio.h>
int ispalindrome(int num)
{
int reversed=0;
while(num != 0)//789
{
reversed = reversed*10 + num%10;
num=num/10;
}
printf("\n the reversed number is %d \n  ",reversed);
if(num==reversed)
{
return 1;
}
else 
{
return 0;
}
};
int main()
{
int n;
printf("\n enter a number you want to check ?  \n");
scanf("%d",&n);
if(ispalindrome(n))
{
printf("\n the number you have entered is palindrome\n");
}
else
{
printf("\n the number you have entered is  not a palindrome\n");
}
printf("bye \n");
return 0;
}
