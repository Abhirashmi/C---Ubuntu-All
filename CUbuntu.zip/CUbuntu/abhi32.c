#include<stdio.h>
int main()
{
int i;
int marks[]={2,4,7};
for(i=0;i<=2;i++);
{
display(marks(i))
}
display(int m)
{
printf("%d",&m);
}
return 0;
}
