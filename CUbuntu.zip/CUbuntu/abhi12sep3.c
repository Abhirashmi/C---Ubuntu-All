#include<stdio.h>
#include<stdlib.h>
int main()
{
int matrix[2][4];
for(int i=0;i<2;i++)
{
printf("enter elements of your matrix %d \n",matrix[i]);
scanf("%d",&matrix[i]);
}
for(int j=0;j<4;j++)
{
printf("enter elements of your matrix %d \n",matrix[j]);
scanf("%d",&matrix[j]);
}
for(int i=0;i<2;i++)
{
for(int j=0;j<4;j++)
{
printf("  matrix  elements of %d row %d column   = {  %d   }\n ",i,j,matrix[i][j]);
}
}
for(int i=0;i<2;i++)
{
for(int j=0;j<4;j++)
{
printf(" {%d %d}\n ",matrix[i][j]);
}
}
printf("bye");
return 0;
}
