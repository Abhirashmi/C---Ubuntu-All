#include<stdio.h>
#include<stdlib.h>
void sum(int a,int b){
int sum=a+b;
printf("sum %d",sum);
}
int main()
{
int x,y;
printf("enter two numbers \n");
printf("number1 %d \n",x);
scanf("%d",&x);
printf("number2 %d \n",y);
scanf("%d",&y);
sum(x,y);
}

