#include<stdio.h>
int func1(int b)
{
printf("the addres of b is %d \n",&b);
return b*100;
};
int main()
{
int b=35;
printf("the addres of b inside main  is %d \n",&b);
int val=func1(b);
printf(" value of func 1 =  %d\n",val);
printf("bye\n");
return 0;
}
