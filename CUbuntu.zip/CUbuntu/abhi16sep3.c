#include<stdio.h>
int sum=89;
int myfunc(int a,int b)
{
extern int sum;
sum=a+b;
return sum;
};
int main()
{
 sum=myfunc(5,6);
printf("the sum is %d\n ",sum);
return 0;
}
