#include<stdio.h>
#include<stdlib.h>
int func1(int array[])
{
int n;
printf("enter the number of values you want to insert in array\n",n);
scanf("%d",&n);
for(int i=1;i<=n;i++)
{
printf("enter the  %d number \n",i);
scanf("%d",&n);
}
for(int i=1;i<=n;i++)
{
printf("the value at %d is %d \n",i,array[i]);
}
return 0;
}
int main()
{
int arr[]={};
func1(arr);
return 0;
}



