#include<stdio.h>
#include<stdlib.h>
int main()
{
//int age,char name;
//age=20;
//name="abhirashmi kumari";

printf("my name is %s and my age is %d","abhirashmi",20);

return 0;
}
