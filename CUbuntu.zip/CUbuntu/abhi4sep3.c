#include<stdio.h>
#include<stdlib.h>
int main()
{
int i=0;
do
{
printf("ABHIRASHMI \n ");
i++;
}
while (i<100);
return 0;
}

