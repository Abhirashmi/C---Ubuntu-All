#include<stdio.h>
int main()
{
char ch;
printf("enter a character\n");
scanf("%c",&ch);
if (ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
printf(" %c yahuuuuuuuu!!!!!!!!! the character input by you is a vowel\n",ch);
else
printf("%c oppppppppsssssss!!!!!!!! the character input by you was not a vowel.\n",ch);
return 0;
}
